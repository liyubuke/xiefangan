// 文档导出：把插件从飞书/i讯飞文档读到的结构化内容（blocks）生成 Word(.docx) 或 Markdown(.md)。
// 纯 Node 无第三方依赖：.docx 是 zip（这里用 store 不压缩，Word/WPS 都认），XML 手拼。
// 个人化检查（share/build.py 的 check_clean）会扫这个文件，不要放本机用户名、令牌、个人路径。
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

// ———————————————— zip（store 模式）————————————————
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
export function zipStore(entries) {
  const chunks = [], central = [];
  let offset = 0;
  for (const e of entries) {
    const name = Buffer.from(e.name, 'utf8');
    const data = Buffer.isBuffer(e.data) ? e.data : Buffer.from(String(e.data), 'utf8');
    const crc = crc32(data);
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0);
    lh.writeUInt16LE(20, 4);      // version needed
    lh.writeUInt16LE(0x0800, 6);  // bit 11: 文件名 UTF-8
    lh.writeUInt16LE(0, 8);       // method 0 = store
    lh.writeUInt16LE(0, 10); lh.writeUInt16LE(0x21, 12); // 时间/日期（固定值）
    lh.writeUInt32LE(crc, 14);
    lh.writeUInt32LE(data.length, 18);
    lh.writeUInt32LE(data.length, 22);
    lh.writeUInt16LE(name.length, 26);
    lh.writeUInt16LE(0, 28);
    chunks.push(lh, name, data);
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0);
    ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8);
    ch.writeUInt16LE(0, 10); ch.writeUInt16LE(0, 12); ch.writeUInt16LE(0x21, 14);
    ch.writeUInt32LE(crc, 16);
    ch.writeUInt32LE(data.length, 20); ch.writeUInt32LE(data.length, 24);
    ch.writeUInt16LE(name.length, 28);
    ch.writeUInt16LE(0, 30);   // extra len
    ch.writeUInt16LE(0, 32);   // comment len
    ch.writeUInt16LE(0, 34);   // disk
    ch.writeUInt16LE(0, 36);   // internal attrs
    ch.writeUInt32LE(0, 38);   // external attrs
    ch.writeUInt32LE(offset, 42);
    central.push(ch, name);
    offset += 30 + name.length + data.length;
  }
  const cd = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(0, 4); end.writeUInt16LE(0, 6);
  end.writeUInt16LE(entries.length, 8); end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(cd.length, 12);
  end.writeUInt32LE(offset, 16);
  end.writeUInt16LE(0, 20);
  return Buffer.concat([...chunks, cd, end]);
}

// ———————————————— 图片信息 ————————————————
export function mimeExt(mime) {
  if (/jpe?g/i.test(mime)) return 'jpg';
  if (/gif/i.test(mime)) return 'gif';
  if (/webp/i.test(mime)) return 'webp';
  if (/bmp/i.test(mime)) return 'bmp';
  return 'png';
}
export function parseDataUrl(dataUrl) {
  const m = /^data:([^;,]+)?;base64,(.*)$/s.exec(String(dataUrl || ''));
  if (!m) return null;
  return { mime: m[1] || 'image/png', ext: mimeExt(m[1] || ''), buf: Buffer.from(m[2], 'base64') };
}
// 从文件头读像素宽高（PNG / JPEG / GIF / BMP / WEBP），失败给默认值
export function imageSize(buf) {
  try {
    if (buf.length > 24 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47)
      return { w: buf.readUInt32BE(16), h: buf.readUInt32BE(20) };
    if (buf.length > 10 && buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46)
      return { w: buf.readUInt16LE(6), h: buf.readUInt16LE(8) };
    if (buf.length > 26 && buf[0] === 0x42 && buf[1] === 0x4d)
      return { w: Math.abs(buf.readInt32LE(18)), h: Math.abs(buf.readInt32LE(22)) };
    if (buf.length > 30 && buf.slice(8, 12).toString() === 'WEBP') {
      const fmt = buf.slice(12, 16).toString();
      if (fmt === 'VP8 ') return { w: buf.readUInt16LE(26) & 0x3fff, h: buf.readUInt16LE(28) & 0x3fff };
      if (fmt === 'VP8L') {
        const b = buf.readUInt32LE(21);
        return { w: (b & 0x3fff) + 1, h: ((b >> 14) & 0x3fff) + 1 };
      }
      if (fmt === 'VP8X') return { w: (buf.readUIntLE(24, 3) & 0xffffff) + 1, h: (buf.readUIntLE(27, 3) & 0xffffff) + 1 };
    }
    if (buf.length > 4 && buf[0] === 0xff && buf[1] === 0xd8) { // JPEG：找 SOFn
      let i = 2;
      while (i + 9 < buf.length) {
        if (buf[i] !== 0xff) { i++; continue; }
        const mk = buf[i + 1];
        if (mk === 0xd8 || mk === 0x01 || (mk >= 0xd0 && mk <= 0xd7)) { i += 2; continue; }
        const len = buf.readUInt16BE(i + 2);
        if (mk >= 0xc0 && mk <= 0xcf && mk !== 0xc4 && mk !== 0xc8 && mk !== 0xcc)
          return { h: buf.readUInt16BE(i + 5), w: buf.readUInt16BE(i + 7) };
        i += 2 + len;
      }
    }
  } catch {}
  return null;
}

// ———————————————— XML 小工具 ————————————————
export function escX(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&apos;')
    // eslint-disable-next-line no-control-regex
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '');
}
function runs(text, { bold = false, italic = false, mono = false, color = '' } = {}) {
  const props = [];
  if (bold) props.push('<w:b/>');
  if (italic) props.push('<w:i/>');
  if (color) props.push(`<w:color w:val="${color}"/>`);
  if (mono) props.push('<w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:eastAsia="等线"/>');
  const rPr = props.length ? `<w:rPr>${props.join('')}</w:rPr>` : '';
  const parts = String(text == null ? '' : text).split('\n');
  const nodes = [];
  parts.forEach((p, i) => {
    if (i) nodes.push('<w:br/>');
    if (p) nodes.push(`<w:t xml:space="preserve">${escX(p)}</w:t>`);
  });
  if (!nodes.length) nodes.push('<w:t xml:space="preserve"></w:t>');
  return `<w:r>${rPr}${nodes.join('')}</w:r>`;
}
function para(inner, { style = '', jc = '', ind = 0, spacing = '' } = {}) {
  const pPr = [];
  if (style) pPr.push(`<w:pStyle w:val="${style}"/>`);
  if (jc) pPr.push(`<w:jc w:val="${jc}"/>`);
  if (ind) pPr.push(`<w:ind w:left="${ind}" w:hanging="${Math.min(ind, 360)}"/>`);
  if (spacing) pPr.push(spacing);
  return `<w:p>${pPr.length ? `<w:pPr>${pPr.join('')}</w:pPr>` : ''}${inner}</w:p>`;
}
function textPara(text, opts = {}, popts = {}) {
  return para(runs(text, opts), popts);
}

const PAGE_W = 11906, MARGIN = 1440, BODY_W = PAGE_W - MARGIN * 2; // A4，单位 twips
const EMU_PER_PX = 9525, MAX_IMG_W = 5.5 * 914400; // 5.5 英寸

// ———————————————— docx ————————————————
// blocks: [{t:'title'|'h'|'p'|'li'|'quote'|'code'|'table'|'img'|'hr', ...}]
// images: [{id, data: dataURL}]；返回 { buf, skipped: [id], used: [id] }
export function buildDocx({ title, blocks, images, maxImgBytes = 3 * 1024 * 1024, maxTotalBytes = 15 * 1024 * 1024 }) {
  const rels = [
    '<Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>',
  ];
  const media = [];
  const imgEntry = new Map(); // id -> { rid, name, buf, w, h }
  let total = 0;
  const skipped = [];
  for (const it of images || []) {
    const parsed = parseDataUrl(it.data);
    if (!parsed) { skipped.push(it.id); continue; }
    if (it.skip) { skipped.push(it.id); continue; }
    if (parsed.buf.length > maxImgBytes || total + parsed.buf.length > maxTotalBytes) { skipped.push(it.id); continue; }
    total += parsed.buf.length;
    const n = media.length + 1;
    const name = `image${n}.${parsed.ext}`;
    const rid = `rIdImg${n}`;
    media.push({ name: `word/media/${name}`, data: parsed.buf });
    rels.push(`<Relationship Id="${rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/${name}"/>`);
    const sz = imageSize(parsed.buf) || { w: 1200, h: 800 };
    imgEntry.set(String(it.id), { rid, name, ...sz });
  }
  let picId = 100;
  const body = [];
  const toc = [0, 0, 0, 0, 0, 0]; // 记录每级标题序号，导出的文档带简单编号更易读；不编号，保持原样
  const listIndent = lv => 420 + Math.max(0, (lv || 1) - 1) * 360;
  for (const b of blocks || []) {
    if (!b || typeof b !== 'object') continue;
    const text = String(b.text == null ? '' : b.text);
    switch (b.t) {
      case 'title': body.push(textPara(title || text, { bold: true }, { style: 'Title', jc: 'center' })); break;
      case 'h': {
        const lv = Math.min(6, Math.max(1, +b.lv || 1));
        body.push(textPara(text, {}, { style: `Heading${lv}` }));
        break;
      }
      case 'p': body.push(textPara(text)); break;
      case 'li': {
        if (b.style === 'ordered') body.push(textPara(`${+b.num > 0 ? +b.num : '•'}. ${text}`, {}, { ind: listIndent(b.lv) }));
        else body.push(textPara(`${b.style === 'todo' ? '☐ ' : '• '}${text}`, {}, { ind: listIndent(b.lv) }));
        break;
      }
      case 'quote': body.push(textPara(text, { italic: true, color: '666666' }, { style: 'Quote', ind: 360 })); break;
      case 'code': body.push(para(runs(text, { mono: true }), { style: 'Code' })); break;
      case 'hr': body.push(para('', { spacing: '<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="D9D9D9"/></w:pBdr>' })); break;
      case 'img': {
        const im = imgEntry.get(String(b.id));
        if (!im) { body.push(textPara('[图片未导出]', { italic: true, color: '999999' })); break; }
        const ratio = im.w && im.h ? im.h / im.w : 0.66;
        const cx = Math.min(Math.round(im.w * EMU_PER_PX), MAX_IMG_W);
        const cy = Math.round(cx * ratio);
        picId++;
        body.push(para(`<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="${cx}" cy="${cy}"/><wp:docPr id="${picId}" name="Picture ${picId}"/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="${picId}" name="${escX(im.name)}"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="${im.rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>`, { jc: 'center' }));
        break;
      }
      case 'table': {
        const rows = Array.isArray(b.rows) ? b.rows.filter(r => Array.isArray(r)) : [];
        if (!rows.length) break;
        const cols = Math.max(1, ...rows.map(r => r.length));
        const cw = Math.floor(BODY_W / cols);
        const border = ['top', 'left', 'bottom', 'right', 'insideH', 'insideV']
          .map(s => `<w:${s} w:val="single" w:sz="4" w:space="0" w:color="BFBFBF"/>`).join('');
        const trs = rows.map((r, ri) => '<w:tr>' + Array.from({ length: cols }, (_, ci) => {
          const v = r[ci] == null ? '' : String(r[ci]);
          const inner = String(v).split('\n').map(line => para(runs(line, ri === 0 ? { bold: true } : {}))).join('');
          return `<w:tc><w:tcPr><w:tcW w:w="${cw}" w:type="dxa"/></w:tcPr>${inner || '<w:p/>'}</w:tc>`;
        }).join('') + '</w:tr>').join('');
        body.push(`<w:tbl><w:tblPr><w:tblW w:w="${BODY_W}" w:type="dxa"/><w:tblBorders>${border}</w:tblBorders><w:tblLayout w:type="fixed"/></w:tblPr><w:tblGrid>${Array.from({ length: cols }, () => `<w:gridCol w:w="${cw}"/>`).join('')}</w:tblGrid>${trs}</w:tbl>${para('')}`);
        break;
      }
      default: if (text.trim()) body.push(textPara(text));
    }
  }
  if (!body.length) body.push(textPara('（空文档）'));
  const documentXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><w:body>${body.join('')}<w:sectPr><w:pgSz w:w="${PAGE_W}" w:h="16838"/><w:pgMar w:top="1440" w:right="${MARGIN}" w:bottom="1440" w:left="${MARGIN}" w:header="851" w:footer="992" w:gutter="0"/></w:sectPr></w:body></w:document>`;
  const exts = new Set(media.map(m => path.extname(m.name).slice(1)));
  const contentTypes = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>${[...exts].map(e => `<Default Extension="${e}" ContentType="image/${e === 'jpg' ? 'jpeg' : e}"/>`).join('')}<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>`;
  const rootRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>`;
  const docRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${rels.join('')}</Relationships>`;
  const buf = zipStore([
    { name: '[Content_Types].xml', data: contentTypes },
    { name: '_rels/.rels', data: rootRels },
    { name: 'word/document.xml', data: documentXml },
    { name: 'word/_rels/document.xml.rels', data: docRels },
    { name: 'word/styles.xml', data: stylesXml() },
    ...media,
  ]);
  return { buf, skipped, used: [...imgEntry.keys()] };
}

function stylesXml() {
  const h = (n, size) => `<w:style w:type="paragraph" w:styleId="Heading${n}"><w:name w:val="heading ${n}"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before="${n <= 2 ? 280 : 200}" w:after="${n <= 2 ? 120 : 80}"/><w:outlineLvl w:val="${n - 1}"/></w:pPr><w:rPr><w:b/><w:sz w:val="${size}"/></w:rPr></w:style>`;
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="微软雅黑"/><w:sz w:val="22"/><w:lang w:val="en-US" w:eastAsia="zh-CN"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="80" w:line="300" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style><w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:jc w:val="center"/><w:spacing w:before="120" w:after="240"/></w:pPr><w:rPr><w:b/><w:sz w:val="44"/></w:rPr></w:style>${[1, 2, 3, 4, 5, 6].map((n, i) => h(n, [36, 30, 26, 24, 22, 22][i])).join('')}<w:style w:type="paragraph" w:styleId="Quote"><w:name w:val="Quote"/><w:basedOn w:val="Normal"/><w:pPr><w:ind w:left="420"/><w:spacing w:before="80" w:after="80"/></w:pPr><w:rPr><w:i/><w:color w:val="666666"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Code"><w:name w:val="Code"/><w:basedOn w:val="Normal"/><w:pPr><w:shd w:val="clear" w:fill="F5F6F7"/><w:spacing w:after="0"/></w:pPr><w:rPr><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas"/><w:sz w:val="19"/></w:rPr></w:style></w:styles>`;
}

// ———————————————— Markdown ————————————————
// 返回 { md, assets: [{name, data}] }；图片按 assets/<basename>.assets/img_<id>.<ext> 存放，md 里用相对路径引用
export function buildMarkdown({ title, blocks, images, baseName = 'document', maxImgBytes = 3 * 1024 * 1024, maxTotalBytes = 15 * 1024 * 1024 }) {
  const assets = [];
  const assetDir = `${baseName}.assets`;
  const byId = new Map();
  let total = 0;
  const skipped = [];
  for (const it of images || []) {
    const parsed = parseDataUrl(it.data);
    if (!parsed || it.skip) { skipped.push(it.id); continue; }
    if (parsed.buf.length > maxImgBytes || total + parsed.buf.length > maxTotalBytes) { skipped.push(it.id); continue; }
    total += parsed.buf.length;
    const name = `${assetDir}/img_${it.id}.${parsed.ext}`;
    assets.push({ name, data: parsed.buf });
    byId.set(String(it.id), name);
  }
  const lines = [];
  const esc = s => String(s == null ? '' : s).replace(/\|/g, '\\|').replace(/\n/g, '<br>');
  lines.push(`# ${title || '文档'}`, '');
  for (const b of blocks || []) {
    if (!b || typeof b !== 'object') continue;
    const text = String(b.text == null ? '' : b.text);
    switch (b.t) {
      case 'title': break; // 已作为一级标题
      case 'h': lines.push(`${'#'.repeat(Math.min(6, (+b.lv || 1) + 1))} ${text}`, ''); break;
      case 'p': lines.push(text, ''); break;
      case 'li': lines.push(`${'  '.repeat(Math.max(0, (b.lv || 1) - 1))}${b.style === 'ordered' ? `${+b.num > 0 ? +b.num : 1}.` : b.style === 'todo' ? '-' : '-'} ${text}`); break;
      case 'quote': lines.push(...text.split('\n').map(l => `> ${l}`), ''); break;
      case 'code': lines.push('```', text, '```', ''); break;
      case 'hr': lines.push('---', ''); break;
      case 'img': {
        const p = byId.get(String(b.id));
        lines.push(p ? `![图 ${b.id}](./${encodeURI(p)})` : `> [图片 #${b.id} 未导出]`, '');
        break;
      }
      case 'table': {
        const rows = Array.isArray(b.rows) ? b.rows.filter(r => Array.isArray(r)) : [];
        if (!rows.length) break;
        const cols = Math.max(1, ...rows.map(r => r.length));
        const clean = r => Array.from({ length: cols }, (_, i) => esc(r[i] == null ? '' : r[i]));
        const head = clean(rows[0]);
        lines.push(`| ${head.join(' | ')} |`, `| ${head.map(() => '---').join(' | ')} |`);
        for (const r of rows.slice(1)) lines.push(`| ${clean(r).join(' | ')} |`);
        lines.push('');
        break;
      }
      default: if (text.trim()) lines.push(text, '');
    }
  }
  return { md: lines.join('\n'), assets, skipped };
}

// ———————————————— 落盘 ————————————————
// 文件名清理：去掉跨平台非法字符和控制字符，保留中文
export function safeName(title, fallback = '文档') {
  const s = String(title || '').replace(/[\\/:*?"<>|\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').trim().replace(/^\.+/, '');
  return (s || fallback).slice(0, 80);
}
export function desktopDir() {
  const d = path.join(os.homedir(), 'Desktop');
  try { if (fs.statSync(d).isDirectory()) return d; } catch {}
  const dl = path.join(os.homedir(), 'Downloads');
  try { if (fs.statSync(dl).isDirectory()) return dl; } catch {}
  return os.homedir();
}
// 不覆盖已有文件：重名时加 -2、-3…
export function uniquePath(dir, base, ext) {
  let p = path.join(dir, `${base}.${ext}`);
  for (let i = 2; fs.existsSync(p) && i < 100; i++) p = path.join(dir, `${base}-${i}.${ext}`);
  return p;
}
// 生成并保存；format='docx'|'md'；返回 { file, skipped, used }
export function exportDocument({ title, format, blocks, images }) {
  const dir = desktopDir();
  const base = safeName(title);
  if (format === 'md') {
    const { md, assets, skipped } = buildMarkdown({ title, blocks, images, baseName: base });
    const file = uniquePath(dir, base, 'md');
    const stem = path.basename(file, '.md');
    // buildMarkdown 里的资源目录名按 baseName 生成；重名加了 -2 时同步改 md 里的引用
    let text = md;
    if (stem !== base) text = text.split(`./${base}.assets/`).join(`./${stem}.assets/`);
    fs.writeFileSync(file, text, 'utf8');
    const assetDir = path.join(dir, `${stem}.assets`);
    if (assets.length) {
      fs.mkdirSync(assetDir, { recursive: true });
      for (const a of assets) fs.writeFileSync(path.join(assetDir, path.basename(a.name)), a.data);
    }
    return { file, skipped, used: assets.length };
  }
  const { buf, skipped, used } = buildDocx({ title, blocks, images });
  const file = uniquePath(dir, base, 'docx');
  fs.writeFileSync(file, buf);
  return { file, skipped, used: used.length };
}

// 把模型输出的 Markdown 转成 blocks（侧边栏「下载结果」用）
export function mdToBlocks(md) {
  const lines = String(md || '').replace(/\r/g, '').split('\n');
  const blocks = [];
  let i = 0;
  const inline = s => String(s || '')
    .replace(/\*\*(.+?)\*\*/g, '$1')
    .replace(/\*(.+?)\*/g, '$1')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1');
  let para = [];
  const flush = () => { if (para.length) { blocks.push({ t: 'p', text: para.join('\n') }); para = []; } };
  while (i < lines.length) {
    const l = lines[i];
    if (/^\s*```/.test(l)) {
      flush();
      const buf = []; i++;
      while (i < lines.length && !/^\s*```/.test(lines[i])) buf.push(lines[i++]);
      i++;
      blocks.push({ t: 'code', text: buf.join('\n') });
      continue;
    }
    if (/^\s*\|.*\|\s*$/.test(l)) {
      flush();
      const rows = [];
      while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) {
        const cells = lines[i].trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map(c => c.trim());
        if (!cells.every(c => /^:?-{2,}:?$/.test(c))) rows.push(cells.map(inline));
        i++;
      }
      if (rows.length) blocks.push({ t: 'table', rows });
      continue;
    }
    const h = l.match(/^(#{1,6})\s+(.*)$/);
    if (h) { flush(); blocks.push({ t: 'h', lv: h[1].length, text: inline(h[2]) }); i++; continue; }
    const ul = l.match(/^(\s*)[-*•]\s+(.*)$/);
    if (ul) { flush(); blocks.push({ t: 'li', style: 'bullet', lv: 1 + Math.floor(ul[1].length / 2), text: inline(ul[2]) }); i++; continue; }
    const ol = l.match(/^\s*(\d+)[.、)]\s+(.*)$/);
    if (ol) { flush(); blocks.push({ t: 'li', style: 'ordered', lv: 1, num: +ol[1], text: inline(ol[2]) }); i++; continue; }
    if (/^\s*(-{3,}|\*{3,})\s*$/.test(l)) { flush(); blocks.push({ t: 'hr' }); i++; continue; }
    if (/^\s*>\s?/.test(l)) {
      flush();
      const buf = [];
      while (i < lines.length && /^\s*>\s?/.test(lines[i])) buf.push(inline(lines[i++].replace(/^\s*>\s?/, '')));
      blocks.push({ t: 'quote', text: buf.join('\n') });
      continue;
    }
    if (!l.trim()) { flush(); i++; continue; }
    const bold = l.match(/^\s*\*\*(.+?)\*\*\s*$/);
    if (bold) { flush(); blocks.push({ t: 'h', lv: 3, text: inline(bold[1]) }); i++; continue; }
    para.push(inline(l));
    i++;
  }
  flush();
  return blocks;
}
