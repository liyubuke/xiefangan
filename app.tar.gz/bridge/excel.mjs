// Excel 导出：把电子表格页面读到的二维数据生成 .xlsx（纯 Node 无依赖，复用 export.mjs 的 zip 写入）。
// 单元格用 inlineStr（不建 sharedStrings），数字自动识别；工作表名按 Excel 规则清理。
import fs from 'node:fs';
import { zipStore, escX, desktopDir, uniquePath, safeName } from './export.mjs';

function colName(n) {
  let s = '';
  n = Number(n) || 0;
  for (n += 1; n > 0; n = Math.floor((n - 1) / 26)) s = String.fromCharCode(65 + ((n - 1) % 26)) + s;
  return s;
}

function cellXml(ref, v) {
  if (v == null || v === '') return '';
  if (typeof v === 'number' && isFinite(v)) return `<c r="${ref}"><v>${v}</v></c>`;
  const s = String(v);
  // 纯数字（长度 < 15 且不是 001 这种编号）写成数值，方便 Excel 直接求和
  if (/^-?\d+(\.\d+)?$/.test(s) && s.length < 15 && !/^-?0\d/.test(s)) return `<c r="${ref}"><v>${s}</v></c>`;
  return `<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${escX(s.slice(0, 32767))}</t></is></c>`;
}

function cleanSheetName(name, used) {
  let s = String(name || 'Sheet').replace(/[\\/:*?\[\]]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 31) || 'Sheet';
  let out = s, i = 2;
  while (used.has(out.toLowerCase())) {
    out = (s.slice(0, 28) + ' ' + i).slice(0, 31);
    i++;
  }
  used.add(out.toLowerCase());
  return out;
}

const STYLES = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="1"><font><sz val="11"/><name val="Calibri"/><family val="2"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;

export function buildXlsx({ sheets }) {
  const used = new Set();
  const metas = [], rels = [], overrides = [], parts = [];
  let idx = 0;
  for (const sheet of sheets || []) {
    idx++;
    const name = cleanSheetName(sheet.name, used);
    const rows = Array.isArray(sheet.rows) ? sheet.rows : [];
    let xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>';
    rows.forEach((row, ri) => {
      if (!Array.isArray(row)) return;
      const cells = [];
      row.forEach((v, ci) => {
        const c = cellXml(colName(ci) + (ri + 1), v);
        if (c) cells.push(c);
      });
      if (cells.length) xml += `<row r="${ri + 1}">${cells.join('')}</row>`;
    });
    xml += '</sheetData></worksheet>';
    parts.push({ name: `xl/worksheets/sheet${idx}.xml`, data: xml });
    metas.push(`<sheet name="${escX(name)}" sheetId="${idx}" r:id="rId${idx}"/>`);
    rels.push(`<Relationship Id="rId${idx}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${idx}.xml"/>`);
    overrides.push(`<Override PartName="/xl/worksheets/sheet${idx}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`);
  }
  if (!idx) {
    // 没有任何工作表时给一张空表，避免生成非法文件
    parts.push({ name: 'xl/worksheets/sheet1.xml', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData/></worksheet>' });
    metas.push('<sheet name="Sheet1" sheetId="1" r:id="rId1"/>');
    rels.push('<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>');
    overrides.push('<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>');
  }
  const contentTypes = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${overrides.join('')}</Types>`;
  const rootRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
  const workbook = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${metas.join('')}</sheets></workbook>`;
  const wbRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${rels.join('')}<Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`;
  return zipStore([
    { name: '[Content_Types].xml', data: contentTypes },
    { name: '_rels/.rels', data: rootRels },
    { name: 'xl/workbook.xml', data: workbook },
    { name: 'xl/_rels/workbook.xml.rels', data: wbRels },
    { name: 'xl/styles.xml', data: STYLES },
    ...parts,
  ]);
}

// sheets: [{ name, rows: [[cell,...],...] }]；最多 2000 行 × 60 列，超出的截断并在结果里注明
export function exportXlsx({ title, sheets, maxRows = 2000, maxCols = 60 }) {
  const cleaned = (sheets || []).map(s => {
    const src = Array.isArray(s.rows) ? s.rows : [];
    let rows = src.slice(0, maxRows).map(r => (Array.isArray(r) ? r.slice(0, maxCols) : []));
    while (rows.length && rows[rows.length - 1].every(c => c == null || String(c).trim() === '')) rows.pop();
    const truncated = src.length > maxRows || src.some(r => Array.isArray(r) && r.length > maxCols);
    return { name: s.name, rows, truncated };
  });
  const file = uniquePath(desktopDir(), safeName(title), 'xlsx');
  fs.writeFileSync(file, buildXlsx({ sheets: cleaned }));
  return { file, sheets: cleaned.length, truncated: cleaned.filter(s => s.truncated).map(s => s.name) };
}
